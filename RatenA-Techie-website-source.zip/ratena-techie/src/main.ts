import './styles.css';

const phone = '9514698986';
const email = 'ratenacbe@gmail.com';
const instagramUrl = 'https://instagram.com/ratenacbe';
const whatsappMessage = encodeURIComponent('Hello RatenA Techie, I would like to know more about your CCTV / 3D printing services.');

const services = [
  { icon: '📹', title: 'CCTV Installation', text: 'New camera installation for homes, shops, offices and private spaces.' },
  { icon: '🛠️', title: 'CCTV Service & Upgrade', text: 'Troubleshooting, camera replacement, DVR/NVR upgrades and system maintenance.' },
  { icon: '📡', title: 'Wi-Fi & 4G Cameras', text: 'Flexible security solutions with Wi-Fi and SIM-based 4G cameras.' },
  { icon: '🧩', title: '3D Printing', text: 'Custom 3D printed parts, prototypes, brackets and practical components.' },
  { icon: '💻', title: 'Computer Service & Support', text: 'Desktop and laptop service, upgrades, software setup, troubleshooting and ongoing technical support.' },
];

const partners = [
  { name: 'Dahua', image: 'https://www.google.com/s2/favicons?domain=dahuasecurity.com&sz=128', url: 'https://www.dahuasecurity.com/in' },
  { name: 'TrueView', image: 'https://www.google.com/s2/favicons?domain=trueview.co.in&sz=128', url: 'https://trueview.co.in/' },
  { name: 'HikVision', image: 'https://www.google.com/s2/favicons?domain=hikvision.com&sz=128', url: 'https://www.hikvision.com/' },
  { name: 'Thinkwill', image: 'https://www.google.com/s2/favicons?domain=thethinkwill.co.in&sz=128', url: 'https://thethinkwill.co.in/' },
  { name: 'HiFocus', image: 'https://www.google.com/s2/favicons?domain=hifocuscctv.com&sz=128', url: 'https://hifocuscctv.com/' },
];

const packages = [
  { name: 'CCTV Setup', price: 'Custom Quote', items: ['Camera + DVR/XVR', 'HDD and accessories', 'Cable & installation', 'Testing and setup'] },
  { name: 'Smart Security', price: 'Custom Quote', items: ['Remote mobile viewing', 'Wi-Fi / IP camera options', 'Audio options', 'System configuration'], featured: true },
  { name: '3D Printing', price: 'From Design', items: ['Custom part printing', 'Prototype development', 'Functional brackets', 'Small-batch jobs'] },
];

function navLink(id: string, label: string): string { return `<a href="#${id}">${label}</a>`; }

const app = document.querySelector<HTMLDivElement>('#app');
if (!app) throw new Error('App root not found');

app.innerHTML = `
<header class="site-header">
  <div class="container nav-wrap">
    <a class="brand" href="#home" aria-label="RatenA Techie home"><span class="brand-mark">R</span><span><strong>RatenA</strong><small>TECHIE</small></span></a>
    <nav class="desktop-nav" aria-label="Main navigation">${navLink('services','Services')}${navLink('packages','Packages')}${navLink('gallery','Gallery')}${navLink('about','About')}${navLink('contact','Contact')}</nav>
    <a class="nav-cta" href="https://wa.me/${phone}?text=${whatsappMessage}" target="_blank" rel="noreferrer">WhatsApp</a>
  </div>
</header>
<main id="home">
<section class="hero"><div class="container hero-grid"><div class="hero-copy">
<p class="eyebrow">CCTV • TECHNOLOGY • 3D PRINTING</p><h1>Smarter security.<br><span>Practical technology.</span></h1>
<p class="hero-text">RatenA Techie helps homes, shops and businesses with reliable CCTV installation, service, upgrades and custom 3D printing solutions.</p>
<div class="hero-actions"><a class="button primary" href="https://wa.me/${phone}?text=${whatsappMessage}" target="_blank" rel="noreferrer">Get a Quote ↗</a><a class="button secondary" href="tel:+91${phone}">Call +91 95146 98986</a></div>
<div class="trust-row"><span>✓ Installation</span><span>✓ Service</span><span>✓ Custom 3D Parts</span></div>
</div><div class="hero-card" aria-label="RatenA services summary"><div class="camera-orbit orbit-one"></div><div class="camera-orbit orbit-two"></div><div class="hero-card-center"><div class="shield">⌂</div><strong>RatenA</strong><span>TECHIE</span></div><div class="floating-card card-one"><b>24/7</b><small>Monitoring Ready</small></div><div class="floating-card card-two"><b>3D</b><small>Custom Printing</small></div></div></div></section>
<section class="highlight-strip"><div class="container"><div class="highlight-heading"><p class="eyebrow">RATENA TECHIE HIGHLIGHTS</p><h2>Security, computer support & custom technology.</h2></div><div class="highlight-grid"><a href="#services"><strong>📹 CCTV</strong><span>Installation • Service • Upgrade</span></a><a href="#computer-service"><strong>💻 Computer Service</strong><span>Repair • Upgrade • Support</span></a><a href="#gallery"><strong>🧩 3D Printing</strong><span>Custom parts • Prototypes</span></a><a href="#partners"><strong>🤝 Product Partners</strong><span>Trusted security brands</span></a></div></div></section>
<section class="section light" id="services"><div class="container"><div class="section-heading"><div><p class="eyebrow">WHAT WE DO</p><h2>Technology that works for you.</h2></div><p>From a single camera to a complete security setup, we focus on practical solutions and clean installation.</p></div><div class="service-grid">${services.map(service => `<article class="service-card"><div class="service-icon">${service.icon}</div><h3>${service.title}</h3><p>${service.text}</p></article>`).join('')}</div></div></section>
<section class="section light computer-section" id="computer-service"><div class="container"><div class="section-heading"><div><p class="eyebrow">COMPUTER SERVICE & SUPPORT</p><h2>Keep your computer fast, reliable and ready.</h2></div><p>Practical computer support for homes, shops and offices, from fixing everyday issues to upgrading older systems.</p></div><div class="computer-grid"><article class="computer-card"><span>01</span><h3>Computer Service</h3><p>Windows troubleshooting, software installation, driver issues, virus cleanup, system errors and general desktop/laptop maintenance.</p></article><article class="computer-card"><span>02</span><h3>Upgrade</h3><p>SSD upgrades, RAM upgrades, storage expansion, graphics upgrades and performance improvement for older PCs.</p></article><article class="computer-card"><span>03</span><h3>Support</h3><p>Setup, data transfer, printer/network assistance, backup guidance and ongoing technical support for home and business users.</p></article></div></div></section>
<section class="section dark" id="packages"><div class="container"><div class="section-heading dark-heading"><div><p class="eyebrow">POPULAR SOLUTIONS</p><h2>Choose what fits your project.</h2></div><p>Every site is different. Contact us for an exact quotation based on your location and requirements.</p></div><div class="package-grid">${packages.map(pkg => `<article class="package-card ${pkg.featured ? 'featured' : ''}">${pkg.featured ? '<div class="badge">POPULAR</div>' : ''}<h3>${pkg.name}</h3><div class="package-price">${pkg.price}</div><ul>${pkg.items.map(item => `<li>✓ ${item}</li>`).join('')}</ul><a href="https://wa.me/${phone}?text=${encodeURIComponent(`Hello RatenA Techie, I am interested in the ${pkg.name} solution.`)}" target="_blank" rel="noreferrer">Enquire on WhatsApp →</a></article>`).join('')}</div></div></section>
<section class="section light partner-section" id="partners"><div class="container"><div class="section-heading"><div><p class="eyebrow">PRODUCT PARTNERS</p><h2>Brands we work with.</h2></div><p>We work with established CCTV and security technology brands to match the right products to each project.</p></div><div class="partner-grid">${partners.map(partner => `<a class="partner-card" href="${partner.url}" target="_blank" rel="noreferrer"><div class="partner-logo"><img src="${partner.image}" alt="${partner.name} logo" loading="lazy" onerror="this.style.display='none';this.nextElementSibling.style.display='grid'"><span>${partner.name.slice(0,2).toUpperCase()}</span></div><strong>${partner.name}</strong><small>Security technology partner</small></a>`).join('')}</div></div></section>
<section class="section light gallery-section" id="gallery"><div class="container"><div class="section-heading"><div><p class="eyebrow">OUR WORK</p><h2>Previous projects.</h2></div><p>Show your completed CCTV installations and custom 3D printed work in separate galleries.</p></div>
<div class="gallery-category"><div class="gallery-title-row"><div><h3>CCTV Installation Projects</h3><p>Previous camera installation, service and upgrade work.</p></div><label class="upload-button">Add CCTV Photos<input class="gallery-upload" type="file" data-gallery="cctv" accept="image/*" multiple></label></div><div class="gallery-grid" id="gallery-cctv"></div></div>
<div class="gallery-category"><div class="gallery-title-row"><div><h3>3D Printing Projects</h3><p>Custom parts, prototypes, brackets and printed components.</p></div><label class="upload-button">Add 3D Photos<input class="gallery-upload" type="file" data-gallery="printing" accept="image/*" multiple></label></div><div class="gallery-grid" id="gallery-printing"></div></div>
<p class="gallery-note">Photos added with these buttons are saved in this browser on this device. To make photos permanently visible to every visitor, add the image files to the website source/assets.</p></div></section>
<section class="section light" id="about"><div class="container about-grid"><div class="about-visual"><span>R</span><small>RatenA Techie</small></div><div><p class="eyebrow">ABOUT RATENA</p><h2>One place for security and practical tech.</h2><p>RatenA Techie combines CCTV installation, computer service and support, 3D printing and technical support. We work with solutions from established security brands such as Hikvision, Dahua and TrueView, while also building custom printed parts for real-world needs.</p><div class="feature-list"><div><b>01</b><span><strong>Professional setup</strong><small>Installation, configuration and testing.</small></span></div><div><b>02</b><span><strong>Practical solutions</strong><small>Hardware selected around your actual requirement.</small></span></div><div><b>03</b><span><strong>After-service support</strong><small>Service and upgrade assistance when you need it.</small></span></div></div></div></div></section>
<section class="contact-section" id="contact"><div class="container contact-box"><div><p class="eyebrow">LET'S TALK</p><h2>Need CCTV or a custom 3D part?</h2><p>Tell us what you need and we will help you choose the right solution.</p><div class="contact-details"><p class="contact-line"><strong>Address</strong><span>Selvapuram, Coimbatore-26</span></p><p class="contact-line"><strong>Email</strong><a href="mailto:${email}">${email}</a></p><p class="contact-line"><strong>Instagram</strong><a href="${instagramUrl}" target="_blank" rel="noreferrer">@ratenacbe</a></p></div></div><div class="contact-actions"><a class="button primary" href="https://wa.me/${phone}?text=${whatsappMessage}" target="_blank" rel="noreferrer">Chat on WhatsApp</a><a class="button outline-light" href="tel:+91${phone}">Call +91 95146 98986</a></div></div></section>
</main>
<footer class="footer"><div class="container footer-wrap"><div><strong>RatenA Techie</strong><p>CCTV • Computer Service • 3D Printing</p></div><div class="footer-links">${navLink('services','Services')}${navLink('gallery','Gallery')}${navLink('about','About')}${navLink('contact','Contact')}</div><div class="footer-social"><a href="${instagramUrl}" target="_blank" rel="noreferrer">Instagram @ratenacbe</a></div><small>© ${new Date().getFullYear()} RatenA Techie. All rights reserved.</small></div></footer>
<a class="floating-whatsapp" href="https://wa.me/${phone}?text=${whatsappMessage}" target="_blank" rel="noreferrer" aria-label="Chat on WhatsApp">WA</a>
`;

type GalleryCategory = 'cctv' | 'printing';
type GalleryData = Record<GalleryCategory, string[]>;
const galleryKey = 'ratena-gallery-v2';
const maxGalleryImages = 12;

function loadGallery(): GalleryData {
  try {
    const saved = JSON.parse(localStorage.getItem(galleryKey) || '{}') as Partial<GalleryData>;
    return { cctv: Array.isArray(saved.cctv) ? saved.cctv : [], printing: Array.isArray(saved.printing) ? saved.printing : [] };
  } catch { return { cctv: [], printing: [] }; }
}
function saveGallery(data: GalleryData): boolean { try { localStorage.setItem(galleryKey, JSON.stringify(data)); return true; } catch { return false; } }
function renderGallery(category: GalleryCategory): void {
  const target = document.querySelector<HTMLDivElement>(`#gallery-${category}`);
  if (!target) return;
  const images = loadGallery()[category];
  if (!images.length) {
    const label = category === 'cctv' ? 'CCTV installation' : '3D printing';
    target.innerHTML = `<div class="gallery-empty"><span>＋</span><strong>Add your ${label} photos</strong><small>Use the upload button above.</small></div>`;
    return;
  }
  target.innerHTML = images.map((src, index) => `<figure class="gallery-item"><img src="${src}" alt="${category === 'cctv' ? 'CCTV installation' : '3D printing'} project ${index + 1}" loading="lazy"><button class="gallery-remove" type="button" data-gallery="${category}" data-index="${index}" aria-label="Remove photo">×</button></figure>`).join('');
}
function resizeImage(file: File): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error('Unable to read image'));
    reader.onload = () => {
      const image = new Image();
      image.onerror = () => reject(new Error('Unable to process image'));
      image.onload = () => {
        const maxDimension = 1400;
        const scale = Math.min(1, maxDimension / Math.max(image.naturalWidth, image.naturalHeight));
        const canvas = document.createElement('canvas');
        canvas.width = Math.max(1, Math.round(image.naturalWidth * scale));
        canvas.height = Math.max(1, Math.round(image.naturalHeight * scale));
        const context = canvas.getContext('2d');
        if (!context) { reject(new Error('Canvas unavailable')); return; }
        context.drawImage(image, 0, 0, canvas.width, canvas.height);
        resolve(canvas.toDataURL('image/jpeg', 0.82));
      };
      image.src = String(reader.result);
    };
    reader.readAsDataURL(file);
  });
}

document.querySelectorAll<HTMLInputElement>('.gallery-upload').forEach(input => {
  input.addEventListener('change', async () => {
    const category = input.dataset.gallery as GalleryCategory;
    const files = Array.from(input.files || []).filter(file => file.type.startsWith('image/'));
    input.value = '';
    if (!files.length) return;
    const data = loadGallery();
    const available = Math.max(0, maxGalleryImages - data[category].length);
    const selected = files.slice(0, available);
    try {
      const images = await Promise.all(selected.map(file => resizeImage(file)));
      const nextData: GalleryData = { ...data, [category]: [...data[category], ...images].slice(-maxGalleryImages) };
      if (!saveGallery(nextData)) { window.alert('Gallery storage is full. Please remove some photos or use smaller images.'); return; }
      renderGallery(category);
    } catch { window.alert('One or more photos could not be added. Please try again with standard image files.'); }
  });
});

document.addEventListener('click', event => {
  const target = event.target as HTMLElement;
  const button = target.closest<HTMLButtonElement>('.gallery-remove');
  if (!button) return;
  const category = button.dataset.gallery as GalleryCategory;
  const index = Number(button.dataset.index);
  const data = loadGallery();
  data[category].splice(index, 1);
  if (saveGallery(data)) renderGallery(category);
});

renderGallery('cctv');
renderGallery('printing');
