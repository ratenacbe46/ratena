RatenA Techie website source
==========================
Run locally:
1. Install Node.js
2. Open this folder in a terminal
3. Run: npm install
4. Run: npm run dev

The website is a Vite static site. Edit src/main.ts for content and
src/styles.css for design, then run npm run build.

Live deployment:
https://ratena-techie-yd0izo.v2.appdeploy.ai/
